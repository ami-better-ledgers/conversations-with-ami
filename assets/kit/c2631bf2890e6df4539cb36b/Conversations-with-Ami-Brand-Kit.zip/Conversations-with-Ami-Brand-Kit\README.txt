CONVERSATIONS WITH AMI - BRAND KIT (v1.0)

Logo/              The logo in four colorways: blue (default), white, light blue, black. SVG, PNG, PDF.
Icon/              The silhouette icon (SVG and PNG) for profile photos and small squares.
Colors-and-Fonts/  Color palette (PNG, CSS, JSON) and the three brand fonts (all free from Google Fonts).
Podcast-Cover/     The official podcast cover art (3000 x 3000 PNG).
Banners/           YouTube, Facebook, LinkedIn and X banners.
Brand-Kit-Terms.txt  The terms you agreed to. Please keep them.

Quick rules: blue logo on light backgrounds, white logo on blue/dark, never stretch or recolor,
keep clear space equal to the height of the red dot. Full guidance: conversationswithami.com/brand-kit
